load('heart_data.mat')
I = im;

[M, N] = size(I);
n = M*N;

mu0 = mean(background_values);
sigma0 = std(background_values);
mu1 = mean(chamber_values);
sigma1 = std(chamber_values);
P1 = @(x) normpdf(x, mu0, sigma0);
P2 = @(x) normpdf(x, mu1, sigma1);
log_cost_P1 = @(x) -log(P1(x)); 
log_cost_P2 = @(x) -log(P2(x));

lambda = 15;

Neighbors = edges4connected(M,N);
i=Neighbors(:,1);
j=Neighbors(:,2);
A = sparse(i,j,lambda,n,n);

T = [log_cost_P1(I(:)) log_cost_P2(I(:))];
T = sparse(T);

[~, Theta] = maxflow(A,T);
Theta = reshape(Theta,M,N);
Theta = double(Theta);

imshow(Theta)

