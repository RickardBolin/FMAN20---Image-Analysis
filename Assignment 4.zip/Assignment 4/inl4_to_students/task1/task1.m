honeycomb = imread('honeycomb.jpg');
binary_honeycomb = imbinarize(rgb2gray(honeycomb));

se = strel('disk',15);
eroded = imerode(binary_honeycomb, se);
dilated = imdilate(eroded, se);

no_filled = binary_honeycomb - dilated;

[L, N] = bwlabel(abs(no_filled-1));

% Keep largest areas
if N > 200
    new_L = zeros(size(L));
    for i = 1:200 + 1
        % Count the most common number in L
        m = mode(L, 'all');
        new_L = new_L + m*(L==m);
        % Set all of the already handled numbers to NaN
        L(L==m) = NaN ;
    end
    L = new_L;
end
imshow(L)


%%
Y = fft2(binary_honeycomb,256,256);
imshow(log(abs(Y)),[-1 5]); colormap(jet); colorbar
